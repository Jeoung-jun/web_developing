function show() {
    var str = "";
    str = form06ex.txt_name.value + "님은\n";
    str = str + form06ex.fruit.value + "를\n좋아하십니다.";
    alert(str);
}