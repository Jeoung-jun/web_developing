function hello() {
    // alert("안녕하세요옹오ㅗㅇㅇ");
    // document.write("Hello world!");
    // console.log("hello world")
    // document.getElementsByTagName('h1')[0].innerHTML = "hello";
}

function show1(){
    document.getElementsByTagName('h2')[0].innerHTML = "안녕하세요";
}

function show2(){
    document.getElementById('d2').innerHTML= "좋은 하루 되세요";
}